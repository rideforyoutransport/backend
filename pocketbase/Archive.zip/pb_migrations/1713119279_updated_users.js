/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("_pb_users_auth_")

  collection.listRule = "verified=true"
  collection.viewRule = "verified=true"
  collection.createRule = "verified=true"
  collection.updateRule = "verified=true"
  collection.deleteRule = null

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("_pb_users_auth_")

  collection.listRule = ""
  collection.viewRule = ""
  collection.createRule = "  verified=true"
  collection.updateRule = "  verified=true"
  collection.deleteRule = ""

  return dao.saveCollection(collection)
})
